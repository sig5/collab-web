
var canvas=document.createElement('canvas');
canvas.setAttribute("id","canvas");
canvas.width=1500;
canvas.height=800;
document.addEventListener('DOMContentLoaded', function() {
    var elems = document.querySelectorAll('.fixed-action-btn');
    var instances = M.FloatingActionButton.init(elems, {
      direction: 'left',
      hoverEnabled: true
    });
  });
  
canvas.style.padding=0;
var lastx,lasty;
document.getElementById("canvas_space").appendChild(canvas);
var context=canvas.getContext('2d');
context.fillStyle='rgb(0,0,0)';
context.fillRect(0,0,1500,800);
context.strokeStyle="#ffffff"
function change_color(color)
{
    context.strokeStyle=color;
}
function change_board_color(color){
    context.fillStyle=color;
    context.fillRect(0,0,1500,800);
}

function change_brush_size(size)
{console.log('here');
    context.lineWidth=parseInt(size);
    console.log(context.lineWidth);
}
let is_mouse_pressed=false;
canvas.addEventListener("mousedown",(e)=>{
    is_mouse_pressed=true;
    
    draw(e.pageX-canvas.offsetLeft,e.pageY-canvas.offsetTop,false);
});
canvas.addEventListener("mousemove",(e)=>{
    if(is_mouse_pressed){
       
        draw(e.pageX-canvas.offsetLeft,e.pageY-canvas.offsetTop,true);
    }
});
canvas.addEventListener("mouseup",(e)=>{
    is_mouse_pressed=false;
});

function draw(x,y, drawing){
    if(drawing)
    {context.beginPath();
    context.lineJoin="round";
    context.moveTo(lastx,lasty);
    context.lineTo(x,y);
    context.closePath();
    context.stroke();}
lastx=x,lasty=y;
}
function save_image()
{
    download=document.getElementById("saver");
    download.setAttribute("href", canvas.toDataURL("image/png").replace("image/png", "image/octet-stream"));
    
}